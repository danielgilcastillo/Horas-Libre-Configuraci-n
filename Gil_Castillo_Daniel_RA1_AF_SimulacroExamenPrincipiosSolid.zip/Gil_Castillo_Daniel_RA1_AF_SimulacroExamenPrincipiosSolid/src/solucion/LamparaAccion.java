


package solucion;

// SRP: Clase que gestiona la acción de encender/apagar la lámpara.
public class LamparaAccion extends Lampara implements Encendible {
  
    @Override
    public void encender() {
        encendida = true;
        System.out.println("Lámpara encendida");
    }
    
    @Override
    public void apagar(){
        encendida = false;
        System.out.println("Lámpara apagada");
    }

    @Override
    public boolean estaEncendida() {
        return encendida;
    }

}
