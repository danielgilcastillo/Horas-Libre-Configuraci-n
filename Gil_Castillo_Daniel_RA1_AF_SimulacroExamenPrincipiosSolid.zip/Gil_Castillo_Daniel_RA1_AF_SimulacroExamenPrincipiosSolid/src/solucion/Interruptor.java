


package solucion;


public class Interruptor {

   // private Lampara lampara;
     public GestorDispositivos gestorDispositivos;  // ARREGLAMOS USANDO DIP
   // DIP: Interruptor depende de la abstracción GestorDispositivos, no de una implementación específica.
    public Interruptor(GestorDispositivos gestorDispositivos) {
        this.gestorDispositivos = gestorDispositivos;
    }

    public void presionar() {
        if(gestorDispositivos.encendible.estaEncendida()) {
            gestorDispositivos.apagar();
        } else {
            gestorDispositivos.encender();
        }
    }
}
