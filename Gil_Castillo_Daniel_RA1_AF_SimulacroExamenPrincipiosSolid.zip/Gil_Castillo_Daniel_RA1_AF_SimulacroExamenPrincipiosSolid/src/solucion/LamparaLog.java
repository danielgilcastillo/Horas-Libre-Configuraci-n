


package solucion;

// SRP: Clase dedicada únicamente al registro de logs de la lámpara.
class LamparaLog extends Lampara implements Hacerlog {
    @Override
    public void guardarLog(String mensaje) {
        // Guardar el log en un archivo (violación de SRP, la clase tiene dos  responsabilidades
         System.out.println("Guardando log: " + mensaje);
    }
}
