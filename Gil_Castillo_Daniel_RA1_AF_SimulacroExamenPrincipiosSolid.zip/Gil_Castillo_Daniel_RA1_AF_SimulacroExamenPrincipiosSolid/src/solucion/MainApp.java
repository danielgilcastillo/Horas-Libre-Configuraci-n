package solucion;

public class MainApp {

    public static void main(String[] args) {
        // Inicializamos las clases de la lámpara y los logs
        LamparaAccion la = new LamparaAccion();
        LamparaLog log = new LamparaLog();
        // Aplicamos DIP al inyectar estas dependencias en el GestorDispositivos
        GestorDispositivos g = new GestorDispositivos(la,log);
         // Creamos el interruptor con el gestor de dispositivos
        Interruptor i = new Interruptor( g );
          
    }       

}
