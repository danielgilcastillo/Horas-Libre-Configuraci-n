La refactorización del código mejora significativamente el diseño del sistema al aplicar los principios SOLID. A continuación, se detalla cómo se logra una mejor estructura, flexibilidad, mantenibilidad y escalabilidad en el sistema refactorizado:

Explicación del nuevo diseño basado en SOLID
Separación de Interfaces (ISP - Interface Segregation Principle)
Originalmente, la interfaz Dispositivo combinaba múltiples responsabilidades, ya que obligaba a implementar métodos para encender, apagar y registrar logs. Esto violaba el principio de ISP, porque no todos los dispositivos que pueden encenderse y apagarse deberían manejar los logs.

En el código refactorizado, se han separado las interfaces en Encendible y Hacerlog. Ahora, una clase que desee implementar solo la funcionalidad de encendido (como LamparaAccion) no está obligada a implementar el registro de logs, y viceversa. Esto permite que cada clase implemente solo las interfaces necesarias, logrando un diseño modular y evitando métodos innecesarios.

Responsabilidad Única (SRP - Single Responsibility Principle)
La clase Lampara en el diseño original tenía dos responsabilidades: controlar el estado de la lámpara (encender/apagar) y manejar los logs, lo cual va en contra de SRP.

En la refactorización, se crean dos clases: LamparaAccion (que implementa la funcionalidad de encendido y apagado) y LamparaLog (que maneja el registro de logs). Esto separa claramente las responsabilidades en clases distintas, lo que facilita el mantenimiento y las futuras modificaciones.

Inversión de Dependencias (DIP - Dependency Inversion Principle)
En el diseño original, la clase Interruptor dependía directamente de la implementación concreta de Lampara, lo cual viola DIP. Esto significa que el sistema estaba acoplado a una implementación específica y no permitía intercambiar diferentes tipos de dispositivos sin modificar Interruptor.

La refactorización introduce la clase GestorDispositivos, que recibe abstracciones (Encendible y Hacerlog) en lugar de implementaciones concretas. Interruptor ahora depende de GestorDispositivos, lo que permite reemplazar cualquier dispositivo que implemente Encendible y Hacerlog sin necesidad de modificar Interruptor. Esto hace el sistema más flexible y escalable.

Principio de Abierto/Cerrado (OCP - Open/Closed Principle)
En el diseño original, agregar un nuevo tipo de dispositivo requeriría modificar Interruptor y Lampara. Esto viola el principio OCP, que establece que las clases deben estar abiertas para extensión, pero cerradas para modificación.

En la refactorización, es posible agregar nuevos dispositivos sin modificar las clases existentes, solo implementando las interfaces Encendible y/o Hacerlog. Interruptor y GestorDispositivos pueden trabajar con cualquier clase que cumpla con estas interfaces, haciendo que el sistema esté abierto para la extensión sin necesidad de modificar el código existente.

Sustitución de Liskov (LSP - Liskov Substitution Principle)
En este nuevo diseño, las clases LamparaAccion y LamparaLog se pueden sustituir por cualquier otra implementación de Encendible o Hacerlog sin romper la funcionalidad. La estructura modular facilita el cumplimiento de LSP, ya que cualquier clase que implemente Encendible o Hacerlog puede reemplazarse sin afectar el comportamiento de Interruptor o GestorDispositivos.


# SOLID Refactorización de Código

Este repositorio contiene un ejemplo de refactorización de código para aplicar los principios SOLID, mejorando la flexibilidad, mantenibilidad y escalabilidad del diseño.

Principios SOLID

1. SRP (Single Responsibility Principle)
Cada clase debe tener una única responsabilidad. En este caso, `LamparaAccion` se encarga de encender/apagar, mientras que `LamparaLog` maneja el registro de logs.

2. OCP (Open/Closed Principle)
El sistema permite la extensión mediante la implementación de interfaces (`Encendible` y `Hacerlog`) sin modificar las clases existentes.

3. LSP (Liskov Substitution Principle)
Clases derivadas (`LamparaAccion`, `LamparaLog`) pueden sustituir a la clase base sin alterar la funcionalidad del sistema.

4. ISP (Interface Segregation Principle)
Se crean interfaces especializadas (`Encendible` y `Hacerlog`) para evitar que las clases implementen métodos innecesarios.

5. DIP (Dependency Inversion Principle)
`Interruptor` y `GestorDispositivos` dependen de abstracciones (interfaces) en lugar de implementaciones concretas, facilitando la inyección de dependencias y el desacoplamiento.

Este diseño modulariza el código y facilita futuras modificaciones y ampliaciones del sistema.


