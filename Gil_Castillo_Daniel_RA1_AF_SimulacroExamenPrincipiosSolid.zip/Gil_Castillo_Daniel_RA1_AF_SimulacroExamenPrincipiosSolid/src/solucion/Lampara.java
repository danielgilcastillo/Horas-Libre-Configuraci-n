


package solucion;

// Clase base Lampara que maneja el estado de encendido.
public class Lampara { 
    
   public   boolean encendida = false;
}
