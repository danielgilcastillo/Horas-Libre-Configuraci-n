


package solucion;


// DIP: La clase GestorDispositivos depende de abstracciones (interfaces Encendible y Hacerlog) en lugar de implementaciones concretas.
public class GestorDispositivos {

    Encendible encendible;
    Hacerlog hacerlog;

    public GestorDispositivos(Encendible encendible, Hacerlog hacerlog) {
        this.encendible = encendible;
        this.hacerlog = hacerlog;
    }
    
    public void encender() {
        encendible.encender();
        hacerlog.guardarLog("Lámpara encendida");
    }

    public void apagar() {
        encendible.apagar();
        hacerlog.guardarLog("Lampara apagada");
    }
} 